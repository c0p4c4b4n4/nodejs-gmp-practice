---
custom_edit_url: null
---

# What to learn next?

Congratulations! 🎉 You've successfully completed the Node.js Global Mentoring Program. You've put in a lot of hard work and dedication and you should definitely be proud of what you've accomplished.

Throughout this program, you've gained a solid foundation in Node.js. You've learned about its core concepts, how to create REST APIs, how to work with SQL and NoSQL databases and how to make your apps production-ready. You've built a strong base for your future projects and learning.

But remember, **learning is a continuous journey**. Node.js is just one tool in the vast landscape of backend development. There's always more and more things to explore and understand. Here are some recommendations for what to study next.

## Docker

During this program, we've "touched" Docker when used it to run databases. However, that's just scratching the surface of what Docker can do.

Docker is a platform that allows you to automate the deployment, scaling, and management of applications. It uses containerization technology to "wrap up" an application with everything it needs to run - including libraries, system tools, and code - and then run it anywhere. This makes it an incredibly powerful tool for backend development and is well worth investing more time in.

To help you get started with Docker, here are some useful resources:
- [Docker Get Started Guide](https://docs.docker.com/get-started/): The official guide from Docker. It's a great place to start if you're new to Docker.
- [Learning Docker](https://www.linkedin.com/learning/learning-docker-17236240): A hands-on course that teaches Docker from scratch.
- [Dockerizing a Node.js Web Application](https://semaphoreci.com/community/tutorials/dockerizing-a-node-js-web-application): Get to learn how to use Node.js with Docker.

## Deployment

There are many ways to deploy a Node.js application. Some popular options include cloud platforms like AWS, Google Cloud, and Azure, as well as platform-as-a-service providers like Heroku and Vercel.

Each option has its own advantages and use cases. We recommend exploring these options and trying to deploy a simple Node.js application to get a feel for how they work.

To help you get started with cloud deployment, please check out the following courses:
- [CloudX: AWS Practitioner for JS](https://learn.epam.com/detailsPage?id=b9980780-4cb1-4ef7-9bb7-204b7a087552)
- [CloudX: Azure Practitioner for JS](https://learn.epam.com/detailsPage?id=764d427f-09e6-463c-9303-ac80eda687c6)

## CI/CD

As you progress in the backend development, mastering Continuous Integration and Continuous Deployment/Delivery is essential. CI/CD streamlines the software delivery process by automating key steps like testing and deployment, therefore enhancing both the speed of development and the quality of the product.

Here are a few resources to get you started with:
- [CI/CD Foundations for JavaScript Engineers](https://learn.epam.com/detailsPage?id=57aedc8e-48f0-4603-9b8e-9d725ed2a390): Learn essential concepts and practical tools for implementing CI/CD workflows tailored specifically for JavaScript projects.
- [Introduction to CI/CD with GitLab](https://docs.gitlab.com/ee/ci/index.html): Learn how to set up a CI/CD pipeline with GitLab.
- [Implementing CI for Node.js Apps with GitHub Actions](https://dev.to/olumidenwosu/implementing-continuous-integration-for-nodejs-apps-with-github-actions-1ag2): Get to know how to setup GitHub Actions for Node.js applications.

## Advanced Backend Development Concepts

While this program covered the core concepts of Node.js, backend development is a vast field with many more topics to explore. Here are some suggestions for what to study next:

- **Microservices**: Learn about how to structure your application as a collection of loosely coupled services. This can help you build scalable and easy-to-maintain applications.

- **GraphQL**: Consider learning GraphQL, a powerful alternative to REST for building APIs. It allows clients to specify exactly what data they need, which can reduce the amount of data that needs to be transferred over the network and improve performance.

- **Websockets**: If you're interested in building real-time applications, consider learning about Websockets. This communication protocol allows for interactive communication between a client and a server.

Remember, the world of backend development is vast and constantly evolving. Stay curious, keep learning, and don't be afraid to dive into new topics.

## Become a Contributor

We believe that the best way to learn is to teach. If you've enjoyed this Node.js program and feel confident in your new skills, consider becoming a contributor or an expert for this program. 

By sharing your knowledge and experiences, you can help us improve this program and make it great for future learners. Plus, teaching is a fantastic way to reinforce what you've learned and gain a deeper understanding of the material.

So, let's make this program great together! If you're interested in contributing, please reach out to us. We would love to welcome you to our team of dedicated educators.

## Final words

Remember, the journey of learning never ends. Keep exploring, keep growing, and keep sharing your knowledge. We can't wait to see where you go from here ❤️