---
custom_edit_url: null
---

# Working with Autocode

## How Autocode works?

[Autocode](https://autocode.epam.com/) is an internal EPAM platform used to **automate the validation of practical tasks** by running tests against submitted code. In the context of the **Node.js Global Mentoring Program**, Autocode ensures that solutions provided by participants meet the acceptance criteria defined in each task.

Autocode **executes each solution in full isolation** — for every submission, it spins up a new container. This container includes: 1) the solution for the practical task 2) predefined tests 3) preconfigured databases (only for modules that require them).

When a solution is submitted, Autocode performs the following steps:

1. **Compile** – runs `npm run build` to compile TypeScript into JavaScript  
2. **Test** – runs `npm run test` to execute the tests on the submitted solution  
3. **Coverage** (Module 4 only) – runs `npm run coverage` to generate a test coverage report

:::tip NOTE
During the **Test** step, the local `src/tests` folder from your branch is **replaced with a predefined `src/tests` folder**. This means that any local changes to your `src/tests` directory will not be used. Autocode will always run the preconfigured tests (which are identical to the ones in your local branch).
:::

## Getting Started with Autocode

Follow the steps below to start working on your practical task using Autocode:

1. **Open task in Autocode.** In the [Learn](https://learn.epam.com/myLearning?tab=OVERVIEW) portal, find the relevant practical task and click "Start" button. This will take you directly to Autocode.

2. **Authorize autocode.git.epam.com**. In Autocode, click on your profile photo → Profile → and then click the "Authorize" button next to autocode.git.epam.com. **This step is required only once.** Make sure you authorize autocode.git.epam.com specifically as all the templates for the program are hosted there.

3. **Start task**. Click the "Start task" button to begin.
    - For your **first task**, this will automatically **fork the [Node.js template](https://autocode.git.epam.com/ld-autocode-js-programs/nodejs-gmp/nodejs-gmp-template) repository** to your autocode.git.epam.com account
    - You **don’t need to fork anything manually**, Autocode handles that for you
    - This template repo contains **all modules** of the Node.js program. Each practical task lives in its **own branch**. So for new tasks, you simply need to **switch to the corresponding branch**

4. **Clone the repo to your local machine**. Once the repository has been forked to your autocode.git.epam.com account, clone it to your local machine using `git clone` command.

5. **Implement your solution**. Now you can start working on the task. Please check "Tips for Working with Autocode" section below for tips on how to structure, test, and debug your solution.

6. **Submit your solution**. When you're ready with some small part of the solution, click the "Submit solution" button in Autocode. It will run `npm run build` to compile your code and `npm run test` to execute the tests.

## Tips for Working with Autocode

Here are a few recommendations to help you get the most out of working with Autocode:

1. **Push early and often.** Don’t wait until your solution is fully complete — push your code to Autocode regularly. Even if some tests fail, early pushes will help you detect issues as soon as they arise. You have up to **99 submission attempts**, and the attempt with the **highest score** will be recorded.

2. **Make sure your tests pass locally.** Local test results are your first checkpoint. If tests fail on your machine, they will definitely fail in Autocode. Use this to catch and fix problems before pushing.

3. **Simulate Autocode’s steps locally.**  Sometimes tests pass locally, but fail in Autocode due to different reasons. Always run the same commands locally that Autocode will use:
    - `npm run build` – to compile TypeScript
    - `npm run test` – to run tests
    - `npm run coverage` – to generate the coverage report (Module 4 only)
4. **Troubleshoot errors.** Autocode does **not expose detailed logs**, which can make debugging tricky. Use your troubleshooting skills to identify the root cause. A good approach is to 1) step back to the last known working state 2) comment out some parts of your code to isolate the issue 3) gradually reintroduce changes to see where things break. This approach can help you narrow down the problem and resolve it more effectively.

5. **Do not modify the `src/tests` folder.** As mentioned earlier, the local `src/tests` folder will be **replaced by a preconfigured version** during execution in Autocode. This means:
   - Do **not** make changes to existing test files
   - Do **not** add new files or helper functions to this folder
   - Do **not** import custom code from `src/tests` into your solution

  Any changes made to this folder will be ignored during validation, resulting in Autocode failing to run tests.

## Common Issues

### 1. Build step fails

Autocode failed to compile your TypeScript code into JavaScript. This usually means there's a syntax error or a type issue. To identify and fix the problem, run the build command locally:

```sh
npm run build
```

Review the error messages shown in your terminal — they will point you to the exact lines causing the failure.

### 2. No tests were executed. Please make sure tests are configured

Autocode couldn't detect or run your tests. This usually points to some misconfiguration in your solution. **The initial templates used for all practical tasks are properly configured to run tests**, so this issue is related to the changes made when working on a solution. Here’s what to check:

- Open `package.json` and ensure the `test` script is correctly defined:

  ```json
  "test": "jest"
  ```

- If you’ve added a `pretest` script (e.g. to seed a database), make sure it doesn’t fail silently. Run this command locally to confirm everything works:

  ```sh
  npm run test
  ```

### 3. Stage execution has exceeded the allowed time limit: 5 minutes

This usually happens when something in your code is hanging, stuck in an infinite loop, or failing to exit properly. Common causes include:
- **Incorrect database credentials** — make sure you're using the exact credentials provided in the task. Invalid credentials may cause the code to keep retrying or hang indefinitely.
- **Seeds or scripts to save data to database are not disconnecting from the database** — if you're running seeds or scripts that connect to the database, ensure all connections are properly closed at the end. Unclosed connections will keep the process alive.

### 4. Coverage report is empty

Autocode couldn't find your test coverage report — most likely because it wasn't generated in the expected format. Autocode requires the `Cobertura` format to parse your coverage results correctly. To fix this, update the coverage script in your package.json:

```js
"coverage": "jest --coverage --coverageReporters=cobertura --coverageDirectory=."
```
