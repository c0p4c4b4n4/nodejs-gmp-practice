---
sidebar_position: 0
custom_edit_url: null
description: What will you learn in this module?
---

# Module overview

## Description

Within this final module you will learn how to prepare your Node.js application to deployment to any remote server or cloud environment.
We will review the best practices (also called **The twelve factors**) that make your app production ready. Additionally, you will discover three more factors which you should consider to make your app Cloud Native (ready for deployment in any Cloud).
Some parts you might already have seen or even applied in your work, but it's always a good thing to recap and strengthen the existing knowledge.

## Learning objectives

**By completing this module, you will:**

- Know what The **Twelve factors app** is
- Know how to **manage configuration properly**
- Know the differences between **development and production environments**
